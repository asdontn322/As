# main.py - Entry point for ButterTerm Cosmic Edition

from butterterm_cosmic import main

if __name__ == "__main__":
    main()
