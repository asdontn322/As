# plugins/hello.py
def main():
    return "🦥 Hello from plugin!"
