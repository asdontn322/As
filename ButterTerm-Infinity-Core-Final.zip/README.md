# ButterTerm: Final Infinity Core
A complete cosmic terminal built for Arch Linux.