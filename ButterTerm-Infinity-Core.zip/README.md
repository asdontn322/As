# ButterTerm: Infinity Core
This is the Cosmic War Edition terminal.
