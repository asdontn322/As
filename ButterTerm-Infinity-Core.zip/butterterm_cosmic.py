# Main terminal script
