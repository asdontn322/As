#!/bin/bash
# Simple example WM simulation
xterm &
sleep 0.5
xterm -e 'btop' &