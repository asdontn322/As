import time, psutil

print("🚀 SlothPower Benchmark Running...
")
for i in range(5):
    cpu = psutil.cpu_percent()
    print(f"🔋 Cycle {i+1}: CPU Load = {cpu}%")
    time.sleep(1)
print("🌌 COSMIC BENCHMARK COMPLETE")