import time, psutil, schedule, subprocess

apps = ['xterm', 'btop']
def launch_usual_apps():
    for app in apps:
        subprocess.Popen([app])

schedule.every().day.at("10:00").do(launch_usual_apps)

while True:
    schedule.run_pending()
    time.sleep(60)