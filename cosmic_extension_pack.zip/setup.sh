#!/bin/bash
echo "🌌 Cosmic Extension – Initializing..."

# Step 1: Setup RAM Disk
mkdir -p /tmp/ramdisk-devilfrv
mount -t tmpfs -o size=512M tmpfs /tmp/ramdisk-devilfrv
echo "RAM Disk mounted at /tmp/ramdisk-devilfrv"

# Step 2: Install dependencies
sudo pacman -S --noconfirm xorg-xprop xdotool python-psutil python-schedule neovim btop bat

echo "Installing slothwm..."
chmod +x slothwm.sh

echo "Setup complete. Enjoy your cosmic ride 🚀"