import logging
import time
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

DOWNLOAD_DIR = os.path.abspath("download_folder")
LOG_FILE = "logs/automation.log"

# Setup logging
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def init_browser():
    chrome_options = Options()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_experimental_option("prefs", {
        "download.default_directory": DOWNLOAD_DIR,
        "download.prompt_for_download": False,
        "safebrowsing.enabled": True
    })
    return webdriver.Chrome(options=chrome_options)

def download_excel():
    driver = init_browser()
    try:
        driver.get("https://the-internet.herokuapp.com/download/TestData.xlsx")
        wait = WebDriverWait(driver, 15)

        view_excel = wait.until(EC.element_to_be_clickable((By.LINK_TEXT, "View in Excel")))
        view_excel.click()
        time.sleep(2)
        driver.switch_to.window(driver.window_handles[-1])

        excel_2000 = wait.until(EC.element_to_be_clickable((By.XPATH, "//input[@type='radio' and contains(@value,'Excel')]")))
        excel_2000.click()

        ok_btn = wait.until(EC.element_to_be_clickable((By.LINK_TEXT, "Ok")))
        ok_btn.click()

        time.sleep(10)  # Wait for download
        logging.info("Excel file downloaded successfully.")
    except Exception as e:
        logging.error(f"Automation failed: {str(e)}")
    finally:
        driver.quit()

if __name__ == "__main__":
    logging.info("Automation started.")
    download_excel()
    logging.info("Automation completed.")
