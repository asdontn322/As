import logging
import time
import subprocess
import os

LOG_FILE = "logs/automation.log"
DOWNLOAD_DIR = os.path.abspath("download_folder")

# Setup logging
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def clear_old_files():
    for f in os.listdir(DOWNLOAD_DIR):
        os.remove(os.path.join(DOWNLOAD_DIR, f))
    logging.info("Cleared old files from download folder.")

def run_step(name, script):
    logging.info(f"STEP START: {name}")
    try:
        if name in ["Upload to SharePoint", "Upload to Google Cloud Platform"]:
            if not os.listdir(DOWNLOAD_DIR):
                logging.warning(f"Skipping {name}: No files in download folder.")
                return
        result = subprocess.run(["python", script], check=True)
        logging.info(f"STEP SUCCESS: {name}")
    except subprocess.CalledProcessError as e:
        logging.error(f"STEP FAILED: {name} with error {e}")
    time.sleep(2)

if __name__ == "__main__":
    logging.info("=== FULL AUTOMATION STARTED ===")
    
    clear_old_files()
    run_step("Download Excel from Legacy Website", "automate.py")
    run_step("Upload to SharePoint", "upload_to_sharepoint.py")
    run_step("Upload to Google Cloud Platform", "upload_to_gcp.py")
    
    logging.info("=== FULL AUTOMATION COMPLETED ===")
