import logging
import time
import os
from selenium import webdriver
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.microsoft import EdgeChromiumDriverManager
from dotenv import load_dotenv

load_dotenv()
DOWNLOAD_DIR = os.path.abspath("download_folder")
LOG_FILE = "logs/automation.log"
CDS_USERNAME = os.getenv("CDS_USERNAME")
CDS_PASSWORD = os.getenv("CDS_PASSWORD")

# Setup logging
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def init_browser():
    edge_options = EdgeOptions()
    edge_options.use_chromium = True
    edge_options.add_argument("--headless=new")
    edge_options.add_argument("--disable-gpu")
    edge_options.add_argument("--ie-mode=IE11")  # Enable IE compatibility mode
    edge_options.add_experimental_option("prefs", {
        "download.default_directory": DOWNLOAD_DIR,
        "download.prompt_for_download": False,
        "safebrowsing.enabled": True
    })
    return webdriver.Edge(service=Service(EdgeChromiumDriverManager().install()), options=edge_options)

def login_to_portal(driver):
    try:
        wait = WebDriverWait(driver, 15)
        username_field = wait.until(EC.presence_of_element_located((By.ID, "cds_id_field")))  # Replace with actual field ID
        password_field = driver.find_element(By.ID, "password_field")  # Replace with actual field ID
        username_field.send_keys(CDS_USERNAME)
        password_field.send_keys(CDS_PASSWORD)
        login_button = driver.find_element(By.ID, "login_button")  # Replace with actual button ID
        login_button.click()
        logging.info("Logged in successfully")
    except Exception as e:
        logging.error(f"Login failed: {str(e)}")
        raise

def download_excel():
    driver = init_browser()
    try:
        driver.get("https://jlr-portal.com/tableau-extract")  # Replace with actual portal URL
        wait = WebDriverWait(driver, 15)
        
        # Handle CDS ID login if required
        if CDS_USERNAME and CDS_PASSWORD:
            login_to_portal(driver)
        
        # Click Tableau Extract link
        tableau_link = wait.until(EC.element_to_be_clickable((By.LINK_TEXT, "Tableau Extract")))
        tableau_link.click()
        
        time.sleep(10)  # Wait for download
        logging.info("Excel file downloaded successfully.")
    except Exception as e:
        logging.error(f"Automation failed: {str(e)}")
    finally:
        driver.quit()

if __name__ == "__main__":
    logging.info("Automation started.")
    download_excel()
    logging.info("Automation completed.")
