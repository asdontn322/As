import os
import logging
from google.cloud import storage
from dotenv import load_dotenv

load_dotenv()
BUCKET_NAME = os.getenv("GCP_BUCKET_NAME")
CREDENTIALS_PATH = os.getenv("GCP_CREDENTIALS_PATH", "credentials.json")
DOWNLOAD_DIR = os.path.abspath("download_folder")
LOG_FILE = "logs/automation.log"

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def upload_latest_file():
    client = storage.Client.from_service_account_json(CREDENTIALS_PATH)
    bucket = client.get_bucket(BUCKET_NAME)

    files = sorted(
        [os.path.join(DOWNLOAD_DIR, f) for f in os.listdir(DOWNLOAD_DIR)],
        key=os.path.getmtime,
        reverse=True
    )

    if not files:
        logging.warning("No files found to upload.")
        return

    latest_file = files[0]
    blob_name = os.path.basename(latest_file)
    blob = bucket.blob(blob_name)
    blob.upload_from_filename(latest_file)
    logging.info(f"Uploaded {blob_name} to bucket {BUCKET_NAME}")

if __name__ == "__main__":
    logging.info("Starting GCP upload.")
    upload_latest_file()
    logging.info("GCP upload completed.")
